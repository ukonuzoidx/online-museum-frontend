import React, { useEffect, useState } from "react";
import EntranceRoom from "./EntranceRoom";
import GalleryRoom1 from "../pages/GalleryRoom1";
import GalleryRoom2 from "../pages/GalleryRoom2";
import GalleryRoom3 from "./GalleryRoom3";
import Restroom from "./RestRoom";
import useMetMuseumArtworks from "../hooks/useMuseumHook";

function MuseumEnvironment({ currentRoom, onDoorClick }) {
  // Fetch all artworks ONCE
  const { artworks, loading } = useMetMuseumArtworks(11, "paintings", 20, ); // Gallery 1
  const { africanArtworks, aloading } = useMetMuseumArtworks(
    5,
    "Sculpture",
    45,
    true
  ); // Gallery 2
  const { drawingsArtworks, dloading } = useMetMuseumArtworks(
    9,
    "Portrait",
    25,
    true
  ); // Gallery 3


  const renderRoom = () => {
    switch (currentRoom) {
      case "Entrance":
        return <EntranceRoom onDoorClick={onDoorClick} />;
      case "Gallery 1":
        return <GalleryRoom1 onDoorClick={onDoorClick} artworks={artworks} />;
      case "Gallery 2":
        return (
          <GalleryRoom2 onDoorClick={onDoorClick} artworks={africanArtworks} />
        );
      case "Gallery 3":
        return <GalleryRoom3 onDoorClick={onDoorClick} artworks={drawingsArtworks} />;
      case "Restrooms":
        return <Restroom onDoorClick={onDoorClick} />;
      default:
        return <EntranceRoom onDoorClick={onDoorClick} />;
    }
  };

  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight
        position={[10, 10, 5]}
        intensity={1}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      {renderRoom()}
    </>
  );
}

export default MuseumEnvironment;
